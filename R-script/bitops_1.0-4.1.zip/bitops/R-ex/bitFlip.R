### Name: bitFlip
### Title: Binary Flip (Not) Operator
### Aliases: bitFlip
### Keywords: arith utilities

### ** Examples

  bitFlip(-1) == 0
  bitFlip(0) == 4294967295
  bitFlip(0,bitWidth=8) == 255



