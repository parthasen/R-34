### Name: cksum
### Title: Compute Check Sum
### Aliases: cksum
### Keywords: arith utilities

### ** Examples

   b <- "I would rather have a bottle in front of me than frontal lobotomy\n"
   cksum(b) == 1342168430 ## -> TRUE



