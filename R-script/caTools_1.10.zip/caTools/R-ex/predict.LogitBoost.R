### Name: predict.LogitBoost
### Title: Prediction Based on LogitBoost Classification Algorithm
### Aliases: predict.LogitBoost
### Keywords: classif

### ** Examples
# See LogitBoost example


