### Encoding: latin1

### Name: doBy
### Title: Various utilities which includes functions for creating
###   groupwise calculations etc.
### Aliases: doBy
### Keywords: utilities

### ** Examples


data(dietox)

summaryBy(Weight+Feed~Evit+Cu+Time,      data=dietox, FUN=c(mean,var),
na.rm=TRUE, use="pair")  

orderBy(~Time+Evit, data=dietox)

splitBy(formula = ~Evit+Cu, data = dietox)

sampleBy(formula = ~Evit+Cu, frac=.1, data = dietox)




