### Encoding: latin1

### Name: dose.LD50
### Title: Calculate LD50
### Aliases: dose.LD50
### Keywords: models

### ** Examples

data(budworm)
m1 <- glm(ndead/20 ~ sex + log(dose), data=budworm, weight=ntotal, family=binomial)
coef(m1)

dose.LD50(m1,c(1,1,NA))
dose.LD50(m1,c(1,0,NA))



