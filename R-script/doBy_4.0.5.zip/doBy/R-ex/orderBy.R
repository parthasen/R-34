### Encoding: latin1

### Name: orderBy
### Title: Ordering (sorting) rows of a data frame
### Aliases: orderBy
### Keywords: utilities

### ** Examples

data(dietox)
orderBy(~Time+Evit, data=dietox)
## Sort decreasingly by Time
orderBy(~-Time+Evit, data=dietox)



