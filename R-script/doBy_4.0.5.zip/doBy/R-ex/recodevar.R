### Name: recodevar
### Title: recode levels of variable
### Aliases: recodevar
### Keywords: utilities

### ** Examples

 x <- c("dec","jan","feb","mar","apr","may")
 src1 <- list(c("dec","jan","feb"), c("mar","apr","may"))
 tgt1 <- list("winter","spring")
 recodevar(x,src=src1,tgt=tgt1)



