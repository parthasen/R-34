### Encoding: latin1

### Name: sampleBy
### Title: Sampling from a data frame
### Aliases: sampleBy
### Keywords: utilities

### ** Examples

data(dietox)
sampleBy(formula = ~Evit+Cu, frac=.1, data = dietox)



