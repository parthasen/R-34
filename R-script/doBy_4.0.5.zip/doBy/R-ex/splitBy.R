### Encoding: latin1

### Name: splitBy
### Title: Split a data frame
### Aliases: splitBy print.splitByData
### Keywords: utilities

### ** Examples

data(dietox)
splitBy(formula = ~Evit+Cu, data = dietox)



