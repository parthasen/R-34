### Encoding: latin1

### Name: transformBy
### Title: Function to make groupwise transformations
### Aliases: transformBy
### Keywords: univar

### ** Examples


data(dietox)
transformBy(~Pig, data=dietox, minW=min(Weight), maxW=max(Weight), 
    gain=sum(range(Weight)*c(-1,1)))




